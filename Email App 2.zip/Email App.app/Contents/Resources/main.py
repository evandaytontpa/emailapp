import sys
from pathlib import Path
from PyQt5.QtCore import Qt, QUrl
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QApplication, QStackedWidget, QVBoxLayout, QWidget
from PyQt5.QtWebEngineWidgets import QWebEngineView
from title_screen import TitleScreen
from template_selector import TemplateSelector
from editor_screen import EditorScreen
from utils.resource import resource_path
from PIL import Image, ImageDraw, ImageFont

sys.path.append("/Users/evandayton/Desktop/Email APP/venv/lib/python3.13/site-packages")



ASSETS_DIR = resource_path("assets")
APP_ICON = Path(resource_path("assets/tpa_logocolor.png"))

DARK_QSS = "QWidget { background:#2c2c2c; color:#e0e0e0; font-family:Arial; font-size:14px; }"
LIGHT_QSS = "QWidget { background:#fafafa; color:#222; font-family:Arial; font-size:14px; }"

class Controller(QWidget):
    def __init__(self):
        super().__init__()
        self.stack = QStackedWidget(self)
        self.preview = QWebEngineView()
        self.title = TitleScreen()
        self.title.finished.connect(lambda: self.stack.setCurrentIndex(1))
        self.selector = TemplateSelector()
        self.selector.templatePicked.connect(self._launch_editor)
        self.selector.themeChanged.connect(self._apply_theme)
        self.stack.addWidget(self.title)
        self.stack.addWidget(self.selector)
        self.stack.addWidget(self.preview)
        lay = QVBoxLayout(self); lay.setContentsMargins(0,0,0,0); lay.addWidget(self.stack)
        self.setWindowTitle("TPA Email Builder β1")
        if APP_ICON.is_file(): self.setWindowIcon(QIcon(str(APP_ICON)))
        self._apply_theme("dark")

    def _launch_editor(self, meta: dict):
        def _return_to_selector():
            self.stack.setCurrentIndex(1)
            self.stack.removeWidget(editor)
            editor.deleteLater()
        editor = EditorScreen(meta["html"], back_cb=_return_to_selector)
        editor.applyStylesheet.emit(self._current_qss)
        editor.requestPreview.connect(self._show_preview)
        self.stack.insertWidget(self.stack.count() - 1, editor)
        self.stack.setCurrentWidget(editor)

    def _show_preview(self, html_path: str):
        self.preview.load(QUrl.fromLocalFile(html_path))
        self.stack.setCurrentWidget(self.preview)

    def _apply_theme(self, mode: str):
        self._current_qss = LIGHT_QSS if mode == "light" else DARK_QSS
        QApplication.instance().setStyleSheet(self._current_qss)
        for editor in self.stack.findChildren(EditorScreen):
            editor.applyStylesheet.emit(self._current_qss)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.stack.setCurrentIndex(0)

def main():
    app = QApplication(sys.argv)
    window = Controller()
    window.resize(1000, 740)
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Controller()  # or whatever your main class is
    window.show()
    sys.exit(app.exec_())