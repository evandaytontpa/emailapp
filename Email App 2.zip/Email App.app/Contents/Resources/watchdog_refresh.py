from watchdog.observers import Observer         # ﻿pip install watchdog
from watchdog.events    import FileSystemEventHandler
from pathlib import Path

class TemplateWatcher(FileSystemEventHandler):
    def __init__(self, template_path, on_change):
        self.template = Path(template_path)
        self.on_change = on_change
    def on_modified(self, event):
        if Path(event.src_path) == self.template:
            self.on_change()

def start_watch(template_path, on_change):
    obs = Observer()
    handler = TemplateWatcher(template_path, on_change)
    obs.schedule(handler, str(Path(template_path).parent))
    obs.start()
    return obs
