from pathlib import Path
from PyQt5.QtCore    import Qt, QTimer, pyqtSignal
from PyQt5.QtGui     import QPixmap
from PyQt5.QtWidgets import QWidget, QLabel, QVBoxLayout

LOGO_FILE = Path("assets", "tpa_logoblack.png")
BG_FILE   = Path("assets", "background.jpg")

class TitleScreen(QWidget):
    finished = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__()

        # ── Background Image ──
        self.bg = QLabel(self)
        self.bg.setScaledContents(False)
        self.bg.setGeometry(self.rect())  # initial sizing
        if BG_FILE.is_file():
            self.bg_pixmap = QPixmap(str(BG_FILE))
            self.bg.setPixmap(self.bg_pixmap)
        self.bg.lower()  # ensure it's at the back

        # ── Foreground Layout ──
        self.logo = QLabel(self)
        if LOGO_FILE.is_file():
            self.logo.setPixmap(QPixmap(str(LOGO_FILE)).scaledToWidth(220, Qt.SmoothTransformation))
        self.logo.setStyleSheet("background: transparent;")
        self.logo.setAlignment(Qt.AlignCenter)

        self.tag = QLabel("Loading", self)
        self.tag.setStyleSheet("font-size:22px; background: transparent; color: white;")
        self.tag.setAlignment(Qt.AlignCenter)

        # Vertical centering
        layout = QVBoxLayout(self)
        layout.addStretch(1)
        layout.addWidget(self.logo, alignment=Qt.AlignHCenter)
        layout.addWidget(self.tag, alignment=Qt.AlignHCenter)
        layout.addStretch(1)
        self.setLayout(layout)

        # ── Loading Dots ──
        self._dots = 0
        self._timer = QTimer(self, timeout=self._tick)
        self._timer.start(350)

        QTimer.singleShot(4000, self._done)

    def resizeEvent(self, event):
        # Keep background scaled proportionally to fill window
        if hasattr(self, 'bg_pixmap'):
            scaled = self.bg_pixmap.scaled(self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            self.bg.setPixmap(scaled)
            self.bg.setGeometry(0, 0, self.width(), self.height())

    def _tick(self):
        self._dots = (self._dots + 1) % 4
        self.tag.setText("Loading" + "." * self._dots)

    def _done(self):
        self._timer.stop()
        self.finished.emit()
