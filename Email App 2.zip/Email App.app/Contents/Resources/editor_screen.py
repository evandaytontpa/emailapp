import os
import re
import base64
import shutil
import uuid
import tempfile
from pathlib import Path
from typing import Dict, List
import datetime


import requests
from PyQt5.QtCore    import Qt, pyqtSignal
from PyQt5.QtWidgets import (
    QWidget, QLabel, QPushButton, QLineEdit, QTextEdit,
    QVBoxLayout, QHBoxLayout, QFileDialog, QGroupBox,
    QScrollArea, QComboBox, QSpinBox, QMessageBox, QCheckBox, QInputDialog
)

from utils.image_generator import generate_text_image, generate_button_image
from utils.email_renderer  import render_email_html

# ───────────────────────── Assets & Paths ────────────────────────────
BRAND_RED   = "#c5143e"
DEFAULT_URL = "https://www.tpaction.com/"

ASSETS_DIR   = "assets"
OUTPUT_DIR   = "output"
HEADER_LOGO  = Path(ASSETS_DIR, "tpa_logocolor.png")

BACKGROUND_DIR = Path(ASSETS_DIR, "backgrounds")
BACKGROUND_DIR.mkdir(exist_ok=True, parents=True)
GRAPHIC_DIR = Path(ASSETS_DIR, "graphics")
GRAPHIC_DIR.mkdir(exist_ok=True, parents=True)

FONTS = {
    "bold":    "fonts/Proxima Nova Bold.otf",
    "regular": "fonts/Proxima Nova Regular.otf",
}

BUTTON_COLOURS: Dict[str, str] = {
    "TPA Red":         "#c5143e",
    "TPA Red Darker":  "#ad0c29",
    "TPA Red Lighter": "#e83d48",
    "Royal Blue":      "#0145f3",
    # …add any others you need…
}

# ───────── Local-upload settings ───────────────────────────
LOCAL_UPLOAD_URL = "http://192.168.101.59:5001/upload"

# ───────────────────────────── QSS Style ──────────────────────────────
STYLE = f"""
QWidget               {{ background:#fafafa; color:#222; font:14px "Arial"; }}
QGroupBox             {{ border:none; margin:0 0 12px 0; padding:12px 16px;
                         background:#ffffff; border-radius:8px;
                         box-shadow:0 2px 6px rgba(0,0,0,.08); }}
QGroupBox::title      {{ subcontrol-origin:margin; left:8px; padding:0 4px;
                         font-weight:600; color:{BRAND_RED}; }}
QLineEdit, QTextEdit,
QComboBox, QSpinBox   {{ border:1px solid #cfcfcf; border-radius:4px;
                         padding:6px 8px; background:#fff; }}
QLineEdit:focus, QTextEdit:focus,
QComboBox:focus, QSpinBox:focus
                      {{ border:2px solid {BRAND_RED}; padding:5px 7px; }}
QPushButton           {{ background:{BRAND_RED}; color:#fff; font-weight:600;
                         border:none; padding:6px 18px; border-radius:4px;
                         min-width:90px; transition:all 120ms; }}
QPushButton:hover     {{ background:#a80e2e; }}
QPushButton:pressed   {{ background:#861125; }}
#toolbar QPushButton  {{ background:transparent; color:#222; padding:4px 12px; }}
#toolbar QPushButton:hover {{ background:rgba(0,0,0,.04); }}
QScrollArea           {{ border:none; }}
QScrollBar:vertical   {{ width:10px; margin:0; background:transparent; }}
QScrollBar::handle    {{ background:{BRAND_RED}; border-radius:5px; }}
"""

# ────────────────────────────── Block ────────────────────────────────
class Block(QWidget):
    """One content block = graphic + CTA"""
    def __init__(self, idx: int):
        super().__init__()
        self.file = ""
        self._ui(idx)

    def _ui(self, idx: int):
        box = QGroupBox(f"Block {idx}")
        l = QVBoxLayout(box); l.setSpacing(6)

        choose = QPushButton("Image"); choose.clicked.connect(self._pick)
        self.lbl = QLabel("none")
        row = QHBoxLayout(); row.setSpacing(6)
        row.addWidget(choose); row.addWidget(self.lbl, 1)
        l.addLayout(row)

        self.link_g = QLineEdit(); self.link_g.setPlaceholderText("Graphic link")
        self.text_c = QLineEdit(); self.text_c.setPlaceholderText("CTA text")
        self.link_c = QLineEdit(); self.link_c.setPlaceholderText("CTA link")
        l.addWidget(self.link_g); l.addWidget(self.text_c); l.addWidget(self.link_c)

        self.colour = QComboBox(); [self.colour.addItem(c) for c in BUTTON_COLOURS]
        self.size   = QSpinBox();  self.size.setRange(30, 100); self.size.setValue(100); self.size.setSuffix("%")
        h = QHBoxLayout(); h.setSpacing(6)
        h.addWidget(QLabel("Colour")); h.addWidget(self.colour)
        h.addSpacing(20)
        h.addWidget(QLabel("Size"));   h.addWidget(self.size)
        l.addLayout(h)

        fx = QHBoxLayout(); fx.setSpacing(6)
        self.shadow_cb = QCheckBox("Drop-shadow")
        self.stroke_cb = QCheckBox("Stroke")
        self.stroke_px = QSpinBox(); self.stroke_px.setRange(1, 10); self.stroke_px.setValue(2)
        fx.addWidget(self.shadow_cb); fx.addSpacing(15)
        fx.addWidget(self.stroke_cb); fx.addWidget(self.stroke_px)
        l.addLayout(fx)

        QVBoxLayout(self).addWidget(box)

    def _pick(self):
        p, _ = QFileDialog.getOpenFileName(
            self, "Image", "", "Images (*.png *.jpg *.jpeg *.gif)"
        )
        if p:
            self.file = p
            self.lbl.setText(Path(p).name)

    def meta(self, btn_png: str) -> Dict:
        return {
            "product_img": self.file.replace("\\", "/"),
            "button_img":  btn_png.replace("\\", "/"),
            "button_link": self.link_c.text().strip() or DEFAULT_URL,
            "button_alt":  self.text_c.text().strip() or "CTA",
            "graphic_pct": self.size.value(),
            "shadow":      self.shadow_cb.isChecked(),
            "stroke_px":   self.stroke_px.value() if self.stroke_cb.isChecked() else 0
        }

# ────────────────────────── EditorScreen ─────────────────────────────
class EditorScreen(QWidget):
    requestPreview  = pyqtSignal(str)
    applyStylesheet = pyqtSignal(str)
    themeChanged    = pyqtSignal(str)

    def __init__(self, template_html: str, back_cb, theme: str="dark"):
        super().__init__()
        self.tpl     = template_html
        self.back_cb = back_cb
        self.theme   = theme
        self.blocks: List[Block] = []

        self.setStyleSheet(STYLE)
        self.applyStylesheet.connect(self.setStyleSheet)
        self._ui()

    def _ui(self):
        v = QVBoxLayout(self); v.setContentsMargins(16, 16, 16, 16); v.setSpacing(8)

        # toolbar
        toolbar = QWidget(); toolbar.setObjectName("toolbar")
        top = QHBoxLayout(toolbar); top.setSpacing(6)

        bk = QPushButton("← Templates"); bk.clicked.connect(self.back_cb)
        thm = QPushButton("☀︎" if self.theme=="dark" else "☾")
        thm.clicked.connect(self._swap_theme)
        upload_btn = QPushButton("Upload to Evan")
        upload_btn.clicked.connect(self._upload_local)

        self.status = QLabel("Ready")

        top.addWidget(bk)
        top.addWidget(thm)
        top.addWidget(upload_btn)
        top.addStretch()
        top.addWidget(self.status)
        v.addWidget(toolbar)

        # Copy box
        copy = QGroupBox("Copy"); cl = QVBoxLayout(copy); cl.setSpacing(6)
        self.head = QTextEdit(); self.head.setFixedHeight(60)
        self.sub  = QTextEdit(); self.sub .setFixedHeight(60)
        cl.addWidget(QLabel("Headline"));     cl.addWidget(self.head)
        cl.addWidget(QLabel("Sub-headline")); cl.addWidget(self.sub)
        v.addWidget(copy)

        # Background selector
        bg_box = QGroupBox("Background"); bgl = QHBoxLayout(bg_box); bgl.setSpacing(8)
        self.bg_combo = QComboBox(); self._refresh_bg_list()
        bgl.addWidget(self.bg_combo, 1)
        up_bg = QPushButton("Upload…"); up_bg.clicked.connect(self._bg_upload)
        bgl.addWidget(up_bg)
        v.addWidget(bg_box)

        # Blocks
        grp = QGroupBox("Blocks"); gl = QVBoxLayout(grp); gl.setSpacing(8)
        self.area = QVBoxLayout()
        inner = QWidget(); inner.setLayout(self.area)
        scr = QScrollArea(); scr.setWidgetResizable(True); scr.setWidget(inner)
        scr.setFixedHeight(300)
        gl.addWidget(scr)
        add = QPushButton("Add Block"); add.clicked.connect(self._add_block)
        gl.addWidget(add, 0, Qt.AlignLeft)
        v.addWidget(grp, 1)
        self._add_block()

        # Action bar
        act = QHBoxLayout(); act.setSpacing(8)
        pv = QPushButton("Preview"); pv.clicked.connect(self._preview)
        sv = QPushButton("Save");    sv.clicked.connect(self._save)
        act.addWidget(pv); act.addWidget(sv); act.addStretch(); act.addWidget(self.status)
        v.addLayout(act)

    def _swap_theme(self):
        self.theme = "light" if self.theme=="dark" else "dark"
        self.applyStylesheet.emit(STYLE)
        self.themeChanged.emit(self.theme)

    def _refresh_bg_list(self):
        self.bg_combo.clear()
        self.bg_combo.addItem("(None)", "")
        for p in sorted(BACKGROUND_DIR.iterdir()):
            self.bg_combo.addItem(p.name, str(p))

    def _bg_upload(self):
        p, _ = QFileDialog.getOpenFileName(
            self, "Choose background", "", "Images (*.png *.jpg *.jpeg)"
        )
        if not p:
            return
        dest = BACKGROUND_DIR / Path(p).name
        shutil.copy(p, dest)
        self._refresh_bg_list()
        self.bg_combo.setCurrentText(dest.name)

    def _add_block(self):
        blk = Block(len(self.blocks) + 1)
        self.blocks.append(blk)
        self.area.addWidget(blk)

    def _render(self, persist: bool) -> str | None:
        # require headline & sub
        if not (self.head.toPlainText().strip() and self.sub.toPlainText().strip()):
            QMessageBox.warning(self, "Missing", "Headline & Sub-headline required")
            return None

        out = OUTPUT_DIR + "/email.html" if persist else str(
            Path(tempfile.gettempdir()) / f"preview_{uuid.uuid4().hex}.html"
        )
        od = Path(out).parent; od.mkdir(parents=True, exist_ok=True)

        # header logo
        header_ref = ""
        if HEADER_LOGO.is_file():
            shutil.copy(HEADER_LOGO, od / HEADER_LOGO.name)
            header_ref = HEADER_LOGO.name

        # generate text images
        h_png = od / "head.png"; s_png = od / "sub.png"
        generate_text_image(self.head.toPlainText(), FONTS["bold"], 28, str(h_png))
        generate_text_image(self.sub.toPlainText(),  FONTS["regular"], 20, str(s_png))

        # content blocks
        parts: List[Dict] = []
        for blk in self.blocks:
            if not blk.file or not blk.text_c.text().strip():
                QMessageBox.warning(self, "Missing", "Each block needs image & CTA text")
                return None

            btn_png = od / f"btn_{uuid.uuid4().hex}.png"
            generate_button_image(
                blk.text_c.text(), FONTS["bold"], str(btn_png),
                fill=BUTTON_COLOURS.get(blk.colour.currentText(), BRAND_RED),
                border="#000", font_size=18, max_width=200
            )

            img_ref = blk.file
            if not img_ref.lower().startswith("http"):
                dest = GRAPHIC_DIR / Path(img_ref).name
                shutil.copy(img_ref, dest)
                img_ref = dest.name
                shutil.copy(dest, od / dest.name)

            meta = blk.meta(btn_png.name)
            meta["product_img"] = img_ref
            parts.append(meta)

        # background pattern
        bg_ref = ""
        bg_data = self.bg_combo.currentData()
        if bg_data:
            dest = od / Path(bg_data).name
            shutil.copy(bg_data, dest)
            bg_ref = dest.name

        # render final HTML
        render_email_html(
            Path(self.tpl).parent, out,
            h_png.name, s_png.name,
            parts, header_ref, "", "",
            [], "", "", "", bg_ref
        )

        # === inline local images only ===
        try:
            html = Path(out).read_text(encoding="utf-8")
            def _inline_img(m):
                src = m.group(1)
                # skip any remote URL
                if src.startswith("http://") or src.startswith("https://"):
                    return m.group(0)
                img_file = Path(out).parent / src
                data = base64.b64encode(img_file.read_bytes()).decode("ascii")
                ext  = img_file.suffix.lower().lstrip(".")
                return f'src="data:image/{ext};base64,{data}"'
            html = re.sub(r'src="([^"]+\.(?:png|jpe?g|gif))"', _inline_img, html)
            Path(out).write_text(html, encoding="utf-8")
        except Exception as e:
            print("⚠️ Inline-image error:", e)

        return out

    def _preview(self):
        f = self._render(False)
        if f:
            self.requestPreview.emit(f)
            self.status.setText("Preview")

    def _save(self):
        f = self._render(True)
        if f:
            QMessageBox.information(self, "Saved", f"Email saved to {f}")
            self.status.setText("Saved ✔︎")

    def _upload_local(self):
        # 0) ask user for a zip basename
        default_name = datetime.datetime.now().strftime("email_%Y%m%d_%H%M%S")
        name, ok = QInputDialog.getText(
            self, "Bundle Name",
            "Enter a name for the ZIP bundle (no extension):",
            text=default_name
        )
        if not ok:
            return
        basename = name.strip() or default_name

        # 1) confirm
        if QMessageBox.question(
            self, "Confirm",
            f"Package this email + graphics into '{basename}.zip' and send it to Evan’s folder?",
            QMessageBox.Yes | QMessageBox.No
        ) != QMessageBox.Yes:
            return

        # 2) render & gather HTML path
        html_path = self._render(True)
        if not html_path:
            return

        pkg_dir = Path(tempfile.gettempdir()) / f"{basename}_pkg"
        pkg_dir.mkdir(exist_ok=True)

        # 3) copy HTML
        pkg_html = pkg_dir / Path(html_path).name
        shutil.copy(html_path, pkg_html)

        # 4) collect both <img> and CSS background refs
        text = pkg_html.read_text(encoding="utf-8")
        img_refs = re.findall(r'src="([^"]+\.(?:png|jpe?g|gif))"', text)
        css_refs = re.findall(r"url\(['\"]?([^'\")]+\.(?:png|jpe?g|gif))['\"]?\)", text)
        asset_refs = set(img_refs + css_refs)

        for rel in asset_refs:
            if rel.startswith("http://") or rel.startswith("https://"):
                continue
            src = Path(html_path).parent / rel
            if src.is_file():
                dst = pkg_dir / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy(src, dst)

        # 5) zip
        zip_base = Path(tempfile.gettempdir()) / basename
        zip_path = shutil.make_archive(str(zip_base), 'zip', pkg_dir)

        # 6) POST
        try:
            with open(zip_path, 'rb') as f:
                resp = requests.post(
                    LOCAL_UPLOAD_URL,
                    files={'file': (f"{basename}.zip", f, 'application/zip')},
                    timeout=30
                )
            resp.raise_for_status()
            saved = resp.json().get("saved", "")
            QMessageBox.information(
                self, "Uploaded",
                f"Bundle '{basename}.zip' uploaded to Evan’s folder:\n{saved}"
            )
            self.status.setText("Uploaded Bundle ✔︎")
        except Exception as e:
            QMessageBox.critical(self, "Upload Error", str(e))
            self.status.setText("Upload Failed")

        # 7) cleanup
        shutil.rmtree(pkg_dir, ignore_errors=True)
        Path(zip_path).unlink(missing_ok=True)
