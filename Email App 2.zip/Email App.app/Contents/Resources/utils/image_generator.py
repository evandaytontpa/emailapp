from PIL import Image, ImageDraw, ImageFont

def _measure(draw, txt, font):
    if hasattr(draw, "textbbox"):
        x0,y0,x1,y1 = draw.textbbox((0,0), txt, font=font); return x1-x0, y1-y0
    return draw.textsize(txt, font=font)

def _wrap(text, font, max_w):
    words=text.split(); lines=[]; line=""; d=ImageDraw.Draw(Image.new("RGB",(1,1)))
    for w in words:
        test=(line+" "+w).strip()
        if _measure(d,test,font)[0]<=max_w: line=test
        else: lines.append(line); line=w
    lines.append(line); return lines

# ---------- headline / subhead ----------
def generate_text_image(text, font_path, size, out, color="#000", max_width=540):
    font=ImageFont.truetype(font_path,size); lines=_wrap(text,font,max_width)
    d=ImageDraw.Draw(Image.new("RGB",(1,1)))
    w=max(_measure(d,l,font)[0] for l in lines); h=_measure(d,lines[0],font)[1]
    img=Image.new("RGBA",(w+40,h*len(lines)+40),(255,255,255,0))
    draw=ImageDraw.Draw(img); y=20
    for l in lines:
        lw=_measure(draw,l,font)[0]
        draw.text(((w+40-lw)/2,y),l,font=font,fill=color); y+=h
    img.save(out); return out

# ---------- button ----------
def generate_button_image(text, font_path, out,
                          font_size=18, fill="#c5143e", txt_color="#fff",
                          border="#000", border_px=4, radius=5,
                          pad_x=28, pad_y=18, max_width=200):
    font=ImageFont.truetype(font_path,font_size)
    d=ImageDraw.Draw(Image.new("RGBA",(1,1))); w,h=_measure(d,text,font)
    w=min(w,max_width-pad_x*2); bw,bh=w+pad_x*2,h+pad_y*2
    img=Image.new("RGBA",(bw,bh),(255,255,255,0)); dr=ImageDraw.Draw(img)
    dr.rounded_rectangle([0,0,bw,bh],radius=radius,fill=fill,outline=border,width=border_px)
    dr.text(((bw-w)/2,(bh-h)/2),text,font=font,fill=txt_color)
    img.save(out); return out
