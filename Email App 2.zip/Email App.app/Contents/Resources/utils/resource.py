import os, sys

def resource_path(relative_path):
    """ Get absolute path to resource (inside PyInstaller or normal run) """
    base_path = getattr(sys, '_MEIPASS', os.path.abspath("."))
    return os.path.join(base_path, relative_path)