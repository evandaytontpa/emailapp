from jinja2 import Environment, FileSystemLoader

def render_email_html(
    template_dir, output_path,
    headline_img, subhead_img, content_blocks,
    header_logo_url, signature_url, black_logo_url,
    social_icons, company_name, company_address,
    unsubscribe_link, background_pattern_url=""
):
    env = Environment(loader=FileSystemLoader(template_dir))
    tpl = env.get_template("base_email.html")

    html = tpl.render(
        background_pattern_url=background_pattern_url,
        header_logo_url=header_logo_url,
        headline_img=headline_img,
        subhead_img=subhead_img,
        content_blocks=content_blocks,
        signature_url=signature_url,
        black_logo_url=black_logo_url,
        social_icons=social_icons,
        company_name=company_name,
        company_address=company_address,
        unsubscribe_link=unsubscribe_link
    )

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
