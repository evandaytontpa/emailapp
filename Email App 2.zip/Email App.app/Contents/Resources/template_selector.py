"""
template_selector.py  – folder / template picker with:
 • Back button
 • Light / Dark themes
 • External drag-and-drop
 • PNG icons (assets/folder.png, assets/template.png)

Signals
-------
templatePicked(meta: dict)   – double-clicked an HTML card
themeChanged(mode: str)      – "dark" | "light"
"""
from __future__ import annotations
import json, shutil, datetime
from pathlib import Path
from typing  import Dict, List

from PyQt5.QtCore   import Qt, QSize, pyqtSignal
from PyQt5.QtGui    import QIcon, QPixmap
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QListWidget, QListWidgetItem, QTreeWidget, QTreeWidgetItem,
    QFileDialog, QInputDialog, QMessageBox, QMenu
)

# ───────────── constants ──────────────────────────────────────────
ROOT = Path("templates")
CARD_SIZE = QSize(150, 110)
ASSETS    = Path("assets")
FOLDER_PNG   = ASSETS/"folder.png"
TEMPLATE_PNG = ASSETS/"template.png"

RED, RED_DK = "#c5143e", "#ad0c29"
CSS_DARK = f"""
QWidget{{background:#2e2e2e;color:#e8e8e8;}}
QPushButton{{background:{RED};color:#fff;border:none;padding:6px 14px;border-radius:4px;}}
QPushButton:hover{{background:{RED_DK};}}
#cards::item{{margin:6px;border:1px solid #444;border-radius:6px;padding:4px;}}
#cards::item:hover{{border:1px solid {RED};}}
#cards::item:selected{{background:{RED};color:#fff;}}
"""
CSS_LIGHT = CSS_DARK.replace("#2e2e2e","#fafafa").replace("#e8e8e8","#222").replace("#444","#bbb")

# ───────────── helpers ────────────────────────────────────────────
def _ensure(folder: Path):
    folder.mkdir(parents=True, exist_ok=True)
    (folder/"layout.html").touch(exist_ok=True)

def _meta(folder: Path) -> Path: return folder/"meta.json"

def _titles(folder: Path) -> Dict[str,str]:
    f=_meta(folder); return json.loads(f.read_text()) if f.exists() else {}

def _save_titles(folder: Path, m:Dict[str,str]): _meta(folder).write_text(json.dumps(m,indent=2))

def _pretty(html: Path, mapping: Dict[str,str]) -> str:
    return mapping.get(html.name, html.stem.replace("_"," ").title())

def _icon(path: Path, fallback):
    return QIcon(str(path)) if path.is_file() else fallback

# ───────────── widget ─────────────────────────────────────────────
class TemplateSelector(QWidget):
    templatePicked = pyqtSignal(dict)
    themeChanged   = pyqtSignal(str)

    def __init__(self, theme="dark"):
        super().__init__()
        self.theme=theme
        self.cwd: Path|None=None
        self.setAcceptDrops(True)
        self._ui(); self._refresh(); self._apply()

    # ---------- UI ----------
    def _ui(self):
        root = QVBoxLayout(self)

        # toolbar
        tb=QHBoxLayout()
        self.back_btn=QPushButton("◀ Back");self.back_btn.clicked.connect(self._back)
        self.new_btn =QPushButton("＋ Folder");self.new_btn.clicked.connect(self._new)
        self.imp_btn =QPushButton("⤓ Import");self.imp_btn.clicked.connect(self._import_html)
        view_btn     =QPushButton("View ▤");  view_btn.clicked.connect(self._toggle)
        thm_btn      =QPushButton("☀︎" if self.theme=="dark" else "☾")
        thm_btn.clicked.connect(self._swap)
        tb.addWidget(self.back_btn);tb.addWidget(self.new_btn);tb.addWidget(self.imp_btn);tb.addWidget(view_btn)
        tb.addStretch();tb.addWidget(thm_btn)
        root.addLayout(tb)

        # sidebar & cards
        body=QHBoxLayout();root.addLayout(body,1)

        left=QVBoxLayout()
        left.addWidget(QLabel("Templates",alignment=Qt.AlignHCenter))
        self.tree=QTreeWidget();self.tree.setHeaderHidden(True)
        self.tree.itemClicked.connect(lambda it:self._enter(ROOT/it.text(0)))
        left.addWidget(self.tree,1);body.addLayout(left,0)

        self.cards=QListWidget(objectName="cards")
        self.cards.setIconSize(CARD_SIZE)
        self.cards.setViewMode(QListWidget.IconMode)
        self.cards.setSpacing(12)
        self.cards.setAcceptDrops(True)
        self.cards.setDragDropMode(QListWidget.InternalMove)
        self.cards.itemDoubleClicked.connect(self._activate)
        self.cards.setContextMenuPolicy(Qt.CustomContextMenu)
        self.cards.customContextMenuRequested.connect(self._context)
        body.addWidget(self.cards,1)

    # ---------- refresh ----------
    def _folders(self): return sorted([p for p in ROOT.iterdir() if p.is_dir()])

    def _refresh(self):
        self.tree.clear(); self.cards.clear()
        for f in self._folders(): QTreeWidgetItem(self.tree,[f.name])
        if self.cwd is None:               # root view → show folders
            icon=_icon(FOLDER_PNG,self.style().standardIcon(getattr(self.style(),"SP_DirIcon")))
            for f in self._folders():
                it=QListWidgetItem(f.name.title()); it.setIcon(icon)
                it.setData(Qt.UserRole,{"type":"folder","path":f})
                self.cards.addItem(it)
        else:                              # inside folder → show html files
            titles=_titles(self.cwd)
            icon=_icon(TEMPLATE_PNG,self.style().standardIcon(getattr(self.style(),"SP_FileIcon")))
            for html in sorted(self.cwd.glob("*.html")):
                it=QListWidgetItem(_pretty(html,titles)); it.setIcon(icon)
                it.setData(Qt.UserRole,{"type":"file","html":html,"folder":self.cwd})
                self.cards.addItem(it)
        self.back_btn.setVisible(self.cwd is not None)
        self.new_btn.setVisible(self.cwd is None); self.imp_btn.setVisible(self.cwd is None)

    # ---------- toolbar slots ----------
    def _back(self): self.cwd=None; self._refresh()
    def _new(self):
        name,ok=QInputDialog.getText(self,"New folder","Name:"); 
        if ok and name.strip():
            dest=ROOT/name.strip().lower().replace(" ","_")
            if dest.exists():return QMessageBox.warning(self,"Exists","Folder exists.")
            _ensure(dest); self._refresh()
    def _import_html(self):
        path,_=QFileDialog.getOpenFileName(self,"Import *.html","","HTML (*.html)")
        if not path:return
        dest=ROOT/f"tpl_{datetime.datetime.now():%Y%m%d_%H%M%S}"; _ensure(dest)
        shutil.copy(path,dest/"layout.html"); self._refresh()
    def _toggle(self):
        m=QListWidget.ListMode if self.cards.viewMode()==QListWidget.IconMode else QListWidget.IconMode
        self.cards.setViewMode(m)
    def _swap(self):
        self.theme="light" if self.theme=="dark" else "dark"; self._apply(); self.themeChanged.emit(self.theme)
    def _apply(self): self.setStyleSheet(CSS_LIGHT if self.theme=="light" else CSS_DARK)

    # ---------- navigation ----------
    def _enter(self,folder:Path): self.cwd=folder; self._refresh()
    def _activate(self,it):
        meta=it.data(Qt.UserRole)
        if meta["type"]=="folder": self._enter(meta["path"])
        else: self.templatePicked.emit(meta)

    # ---------- context ----------
    def _context(self,pos):
        it=self.cards.itemAt(pos); meta=it and it.data(Qt.UserRole)
        if not meta:return
        menu=QMenu(self)
        if meta["type"]=="file":
            rn=menu.addAction("Rename")
            if menu.exec_(self.cards.mapToGlobal(pos))==rn:self._rename(meta,it)
        elif meta["type"]=="folder":
            rm=menu.addAction("Delete")
            if menu.exec_(self.cards.mapToGlobal(pos))==rm:self._del(meta)
    def _rename(self,meta,it):
        titles=_titles(meta["folder"])
        new,ok=QInputDialog.getText(self,"Rename","Display name:",text=it.text())
        if ok and new.strip(): titles[meta["html"].name]=new.strip(); _save_titles(meta["folder"],titles); self._refresh()
    def _del(self,meta):
        if QMessageBox.question(self,"Delete",f"Delete {meta['path'].name}?")==QMessageBox.Yes:
            shutil.rmtree(meta["path"],ignore_errors=True); self.cwd=None; self._refresh()

    # ---------- dnd ----------
    def dragEnterEvent(self,e):                                # noqa: N802
        if e.mimeData().hasUrls(): e.acceptProposedAction()
    def dropEvent(self,e):                                     # noqa: N802
        for url in e.mimeData().urls():
            p=Path(url.toLocalFile())
            if p.is_dir():
                dest=ROOT/p.name; shutil.copytree(p,dest,dirs_exist_ok=True)
                if not any(dest.glob("*.html")):_ensure(dest)
            elif p.suffix.lower()==".html":
                dest=ROOT/f"tpl_{datetime.datetime.now():%Y%m%d_%H%M%S}"
                _ensure(dest); shutil.copy(p,dest/"layout.html")
        self.cwd=None; self._refresh()
